ATHHHHH CUTUUUUUU DIGITAL CARD

Files:
- index.html
- media/ath-photo.jpg
- media/ath-video.mp4

GitHub Pages:
1. Create a public GitHub repository named athhhhh
2. Upload index.html
3. Create a folder named media
4. Upload ath-photo.jpg and ath-video.mp4 inside media
5. Settings -> Pages -> Deploy from a branch
6. Branch: main
7. Folder: / (root)
8. Save
9. Open the Visit site link after GitHub finishes publishing.

IMPORTANT:
Keep the filenames exactly the same.
